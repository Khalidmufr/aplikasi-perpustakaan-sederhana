/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fungsi;

import fungsi.Voucher;

/**
 *
 * @author ACER
 */
public interface topup {
   
   public Voucher[] getAll();
   
   public void add(Voucher voucher);
   
   public void change(Voucher voucher);
   
   public boolean remove(Integer number);
//    boolean isExists(Integer number);
}
